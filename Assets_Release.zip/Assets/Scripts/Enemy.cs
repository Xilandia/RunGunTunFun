using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Enemy : MonoBehaviour
{
    private Animator anim;

	public float speed;
	private Transform target;

	public int damage;
	public int health;
	public float deathAnimTime = 1f;
	private bool dying = false;

	public bool isPatrol;
	public float minX;
	public float maxX;
	public float minY;
	public float maxY;
	private Vector2 patrolTarget;

    public string moveAnimation;

	private void Start()
	{
		anim = GetComponent<Animator>();

		target = GameObject.FindGameObjectWithTag("Player").transform;

		patrolTarget = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
	}

	private void Update()
	{
		if(health > 0) {
        	anim.Play(moveAnimation);
			if(isPatrol){
				transform.position = Vector2.MoveTowards(transform.position, patrolTarget, speed * Time.deltaTime);

				if(Vector2.Distance(transform.position, patrolTarget) < 0.2f){ 
					patrolTarget = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
				}
			} else{
				transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
			}
		}		
		else 
		{ 
			if(dying == false) {
				dying = true;
            	anim.SetTrigger("dead");
				Destroy(gameObject, deathAnimTime);
			}
		}

	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		if (dying == false) {
			if(other.CompareTag("Player")){ 
				other.GetComponent<Player>().TakeDam(damage);
			}
		}
	}

}
