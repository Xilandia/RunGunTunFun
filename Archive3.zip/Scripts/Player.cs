using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Player : MonoBehaviour
{
    public float speed;

    private Animator anim;

    public float dashBoost;
	private float dashTime;
	public float startDashTime;
	private bool once;
	private float x;
	private float y;
	public int health;
	private float safeTime;
	public float startSafeTime;
	public bool isDead = false;

    private void Start()
	{
		anim = GetComponent<Animator>();
		DontDestroyOnLoad(gameObject);
		GameObject projectile = GameObject.FindGameObjectWithTag("ProjectilePlayer");
		Physics2D.IgnoreCollision(GetComponent<Collider2D>(), projectile.GetComponent<Collider2D>());
	}

    private void Update()
    {
        if(Input.GetMouseButtonDown(1) && once == false){ 
			speed += dashBoost;
			once = true;
			dashTime = startDashTime;
		}

		if (dashTime < 0 && once == true)
		{			
			speed -= dashBoost;
			once = false;
		} else{ 
			dashTime -= Time.deltaTime;
		}

		x = Input.GetAxisRaw("Horizontal");
		y = Input.GetAxisRaw("Vertical");

		Vector3 moveInput = new Vector3(x, y, 0);
        transform.position += moveInput.normalized * speed * Time.deltaTime;

		Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
		float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        if (moveInput != Vector3.zero)
        {
			if (x == 1) {
				anim.Play("WalkRight");
			}
			else if (x == -1) {
				anim.Play("WalkLeft");
			}
			else if (y == 1) {
				anim.Play("WalkUp");
			}
			else if (y == -1) {
				anim.Play("WalkDown");
			}
		}
		else
		{
			if (angle < -90) {
				anim.Play("Idle225");
			}
			else if (angle > 90) {
				anim.Play("Idle135");
			}
			else if (angle > 0) {
				anim.Play("Idle45");
			}
			else {
				anim.Play("Idle315");
			}
		}

		if(safeTime > 0){ 
			safeTime -= Time.deltaTime;
		}


		if(health <= 0){ 
			speed = 0;
			isDead = true;
		}

    }
	
	public void TakeDam(int dam){ 
		if(safeTime <= 0){
			anim.Play("Hurt");
			health -= dam;
			safeTime = startSafeTime;
		}
	}
}