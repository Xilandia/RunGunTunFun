using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class Enemy : MonoBehaviour
{
    private Animator anim;

	public float speed;
	private Transform target;

	public int damage;
	public int health;
	private bool dying = false;

	public bool isPatrol;
	public float minX;
	public float maxX;
	public float minY;
	public float maxY;
	private Vector2 patrolTarget;
    
    public string deathAnimation;
    public string moveAnimation;

	private void Start()
	{
		anim = GetComponent<Animator>();

		target = GameObject.FindGameObjectWithTag("Player").transform;

		patrolTarget = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
	}

	private void Update()
	{
        anim.Play(moveAnimation);
		if(isPatrol){
			transform.position = Vector2.MoveTowards(transform.position, patrolTarget, speed * Time.deltaTime);

			if(Vector2.Distance(transform.position, patrolTarget) < 0.2f){ 
				patrolTarget = new Vector2(Random.Range(minX, maxX), Random.Range(minY, maxY));
			}
		} else{
			transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
		}
		

		if(health <= 0){ 

			int randChance = Random.Range(0, 20);
			if(randChance == 1){
				// if we want to do drops
			}
			if (dying == false) {
				dying = true;
            	anim.Play(deathAnimation);

				Destroy(gameObject, 1f);
			}
		}


	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		if (dying == false) {
			if(other.CompareTag("Player")){ 
				other.GetComponent<Player>().TakeDam(damage);
			}
		}
	}

}
