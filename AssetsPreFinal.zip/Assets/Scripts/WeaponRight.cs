using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponRight : MonoBehaviour
{
	public float projectileSpeed = 20;
    public float rotSpeed;
	public float weapon = 2;

	public GameObject projectile;
	public Transform spawnPos;
	private float timeBtwShots;
	public float startTimeBtwShots;
	private Animator anim;

    private void Start()
	{
		anim = GetComponent<Animator>();
	}
	private void Update()
	{
		Vector2 direction = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
		float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
		Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);
		transform.rotation = Quaternion.Slerp(transform.rotation, rotation, rotSpeed * Time.deltaTime);
		
		if (angle > 90 || angle < -90) {
			this.GetComponent<Renderer>().enabled = false;
		} else {
			this.GetComponent<Renderer>().enabled = true;
		if (weapon == 1) {
			if(Input.GetMouseButtonDown(0)){
				Shoot();
			}

			if(Input.GetMouseButton(0)){

				if(timeBtwShots <= 0)
				{
					Instantiate(projectile, spawnPos.position, transform.rotation);
					timeBtwShots = startTimeBtwShots;
				}
				else
				{
					timeBtwShots -= Time.deltaTime;
				}
			} 
		}
		if (weapon == 2) {
			if(Input.GetMouseButtonDown(0)){
				Shoot();
			}

			if(Input.GetMouseButton(0)){

				anim.Play("FiringRight");
				

				if(timeBtwShots <= 0)
				{
					Shoot();
					timeBtwShots = startTimeBtwShots;
				}
				else
				{
					timeBtwShots -= Time.deltaTime;
				}
			} else {
				anim.Play("StandingRight");
			}
		}
		}
	}
	private void Shoot()
	{
		GameObject bullet = Instantiate(projectile, spawnPos.position, spawnPos.rotation);
		Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
		rb.AddForce(transform.right * projectileSpeed, ForceMode2D.Impulse);
	}
}
