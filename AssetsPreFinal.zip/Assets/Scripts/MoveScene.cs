using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MoveScene : MonoBehaviour
{
    [SerializeField] private string newLevel;
    [SerializeField] private Vector3 returnPosition;

    private Transform player;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    //Save player's current position before loading new scene
    private void OnTriggerEnter2D(Collider2D other) 
    {
        if (other.CompareTag("Player"))
        {
            player.position = returnPosition;
            SceneManager.LoadScene(newLevel);
            //Move player to the stored position
        }
    }

}

