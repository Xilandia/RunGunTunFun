using UnityEngine;

public class Overlay : MonoBehaviour
{
    void Start()
    {
        DontDestroyOnLoad(gameObject);
    }
}