using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorFollow : MonoBehaviour
{

    public float rotSpeed;

	private void Start()
	{
		Cursor.visible = false;
	}
	private void Update()
	{
		Vector2 cursorPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		transform.position = Vector2.MoveTowards(transform.position, cursorPos, 100 * Time.deltaTime);
        transform.Rotate(Vector3.forward * rotSpeed * Time.deltaTime);
	}
}
